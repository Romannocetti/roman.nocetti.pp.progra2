package primer_parcial;


public class Mamiferos extends Animal{
    
    private double peso;
    private Dieta dieta;

    public Mamiferos(double peso, Dieta dieta, String nombre, int edad) {
        super(nombre, edad);
        this.peso = peso;
        this.dieta = dieta;
    }
    
    @Override
    public void vacunar() {
        System.out.println(getNombre() + "ha sido vacunado");
    }

    @Override
    public String toString() {
        return "Mamiferos{" +getNombre()+ "edad" + getEdad() + "peso=" + peso + ", dieta=" + dieta + '}';
    }
    
    
}
