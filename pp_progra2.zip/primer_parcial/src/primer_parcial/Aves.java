package primer_parcial;


public class Aves extends Animal {
    
    private double envergaduraAlas;

    public Aves(double envergaduraAlas, String nombre, int edad) {
        super(nombre, edad);
        this.envergaduraAlas = envergaduraAlas;
    }
    


    @Override
    public void vacunar() {
        System.out.println(getNombre() + " ha sido vacunado");
    }

    @Override
    public String toString() {
        return "Aves{" +getNombre()+ "edad" + getEdad() + "envergaduraAlas=" + envergaduraAlas + '}';
    }
    
    
    
}
