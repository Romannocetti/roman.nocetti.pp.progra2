package primer_parcial;

public class YaExisteException extends RuntimeException {
    private static final String MESSAGE = " ya existe ese animal en el zoologico. ";

    public YaExisteException(){
       super(MESSAGE);
    }
}
