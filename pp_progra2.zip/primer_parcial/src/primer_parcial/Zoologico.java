package primer_parcial;

import java.util.ArrayList;
import java.util.List;

public class Zoologico {
    private List<Animal> animales = new ArrayList<>();
    
    public void agregarAnimal(Animal a){
        if(animales.contains(a) ){
            throw new YaExisteException();
        }
        if(animales == null){
            throw new NullPointerException();
        }
        animales.add(a);
    }
    
    
    public void mostrarAnimales(){
        for(Animal a: animales ){
            System.out.println(a);
        }     
    }
    
    public void vacunarAanimales(){
        for(Animal a : animales){
            if(a instanceof Mamiferos || a instanceof Aves){
            a.vacunar();
            }
        }
    }
    
    
}
