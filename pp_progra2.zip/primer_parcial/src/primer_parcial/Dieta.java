package primer_parcial;

public enum Dieta {
    HERBIVORO,
    CARNIVORO,
    OMNIVORO;
}
