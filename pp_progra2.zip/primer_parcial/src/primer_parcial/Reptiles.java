package primer_parcial;


public class Reptiles extends Animal{
    
   private String tipoEscama;
   private String regulartemperatura;

    public Reptiles(String tipoEscama, String regulartemperatura, String nombre, int edad) {
        super(nombre, edad);
        this.tipoEscama = tipoEscama;
        this.regulartemperatura = regulartemperatura;
    }
   
   


    @Override
    public void vacunar() {
        System.out.println(getNombre()+ "no puede ser vacunado ya que es un reptil");
    }

    @Override
    public String toString() {
        return "Reptiles{"+getNombre()+ "edad" + getEdad()  + "tipoEscama=" + tipoEscama + ", regulartemperatura=" + regulartemperatura + '}';
    }
    
    
    
}
