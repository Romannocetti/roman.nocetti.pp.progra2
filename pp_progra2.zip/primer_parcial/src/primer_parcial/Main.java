package primer_parcial;


public class Main {

    public static void main(String[] args) {
        Zoologico z = new Zoologico();
        Animal a1 = new Mamiferos(50.0,Dieta.HERBIVORO, "roman", 12);
        Animal a2 = new Aves(35.3, "lucia", 2 );
        Animal a3 = new Reptiles("queratinosa", "ectotermia", "rodri", 5);
        Animal a4 = new Mamiferos(50.0,Dieta.HERBIVORO, "roman", 12);
            
            
        try{    

            z.agregarAnimal(a1);
            z.agregarAnimal(a2);
            z.agregarAnimal(a3);
            z.agregarAnimal(a4);
        
            
            z.vacunarAanimales();
        }
        catch(Exception e){
            System.out.println(e.getMessage()); 
        }
            z.mostrarAnimales();
    }
}